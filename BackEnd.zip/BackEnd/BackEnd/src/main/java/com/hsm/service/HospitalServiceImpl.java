package com.hsm.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.hsm.daos.HospitalDao;
import com.hsm.entity.Doctor;
import com.hsm.entity.Hospital;

@Service
@Transactional
public class HospitalServiceImpl implements HospitalService {
	
	@Autowired
	private HospitalDao hospitalDao;
	
	@Autowired
	private PasswordEncoder passEncoder;

	public Hospital addHospital(Hospital hospital) {
		hospital.getUser().setPassword(passEncoder.encode(hospital.getUser().getPassword()));
		hospital.getUser().setRole("hospital");
		return hospitalDao.save(hospital);
	}

	public List<Hospital> getAll() {
		return hospitalDao.findAll();
	}

}
