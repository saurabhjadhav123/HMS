package com.hsm.daos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hsm.entity.Doctor;

public interface DoctorDao extends JpaRepository<Doctor, Integer> {

}
