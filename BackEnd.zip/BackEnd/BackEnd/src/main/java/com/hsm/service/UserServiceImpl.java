package com.hsm.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hsm.daos.UserDao;
import com.hsm.entity.Users;

@Service
@Transactional
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserDao userDao;
	
	@Override
	public List<Users> getUsers() {
		return userDao.findAll();
	}
	@Override
	public Users findByEmail(String uname) {
		return userDao.findByEmail(uname);
	}
	public Users saveUser(Users user) {
		return userDao.save(user);
	}

	
	
}
