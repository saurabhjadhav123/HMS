package com.hsm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.hsm.entity.Doctor;
import com.hsm.entity.Hospital;
import com.hsm.entity.Patient;
import com.hsm.entity.Users;
import com.hsm.service.DoctorServiceImpl;
import com.hsm.service.HospitalServiceImpl;
import com.hsm.service.PatientServiceImpl;
import com.hsm.utils.Response;

@CrossOrigin
@RestController
public class AdminController {
	
	@Autowired
	DoctorServiceImpl ds;
	
	@Autowired
	private HospitalServiceImpl hs;
	
	@Autowired
	private PatientServiceImpl ps; 
	

	@PostMapping("/addhospital")
	public ResponseEntity<?> getDoctors(@RequestBody Hospital hospital) {
		Hospital newHospital=hs.addHospital(hospital);
		return Response.success(newHospital!=null);
	}

	@GetMapping("/doctorlist")
	public ResponseEntity<?> getDoctors() {
		List<Doctor> list=ds.getAll();
		return Response.success(list);
	}
		
	@GetMapping("/hospitallist")
	public ResponseEntity<?> getHospitals() {
		List<Hospital> list=hs.getAll();
		return Response.success(list);
	}
	@GetMapping("/patientlist")
	public ResponseEntity<?> getPatients() {
		List<Patient> list=ps.getAll();
		return Response.success(list);
	}
}
