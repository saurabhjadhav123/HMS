package com.hsm.controller;

import java.util.Arrays;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;


import com.hsm.entity.Users;
import com.hsm.models.AuthenticationRequest;
import com.hsm.models.AuthenticationResponse;
import com.hsm.service.MyUserDetailsService;
import com.hsm.service.UserServiceImpl;
import com.hsm.utils.JwtUtil;
import com.hsm.utils.Response;

@CrossOrigin
@RestController
public class UserController {
	@Autowired
	private JwtUtil jwtutil;
	
	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtUtil jwtTokenUtil;

	@Autowired
	private MyUserDetailsService userDetailsService;
	
	@Autowired
	private PasswordEncoder passEncoder;
	
	@Autowired
	private UserServiceImpl us;
	

	
	@PostMapping("/authenticate")
	public ResponseEntity<?> createAuthenticationToken(@RequestBody AuthenticationRequest authenticationRequest) throws Exception {
			authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(authenticationRequest.getUsername(), authenticationRequest.getPassword()));
		final UserDetails userDetails = userDetailsService
				.loadUserByUsername(authenticationRequest.getUsername());

		final String jwt = jwtTokenUtil.generateToken(userDetails);

		return Response.success(new AuthenticationResponse(jwt));
	}
	@GetMapping("/getrole")
	public ResponseEntity<?> getRole(@RequestHeader("Authorization") String token) {
		String uname=jwtutil.getCurrentUser(token);
		Users entity=us.findByEmail(uname);
		entity.setPassword(null);
		return Response.success(entity);	
	}
	@PostMapping("/register")
	public ResponseEntity<?>  addUser(@RequestBody Users user) {
		System.out.println(user.getPassword());
		user.setPassword(passEncoder.encode(user.getPassword()));
		Users newUser=us.saveUser(user);
		return Response.success(newUser!=null);
	}
	}
