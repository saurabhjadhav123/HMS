package com.hsm.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "doctor")
public class Doctor {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int did;
	private String name;
	private int mobile;
	private String specialization;
	private String email;
	private String password;

	
	public Doctor() {
		// TODO Auto-generated constructor stub
	}

	public Doctor(int did, String name, int mobile, String specialization, String email, String password, int hid) {
		super();
		this.did = did;
		this.name = name;
		this.mobile = mobile;
		this.specialization = specialization;
		this.email = email;
		this.password = password;
		
	}

	public int getDid() {
		return did;
	}

	public void setDid(int did) {
		this.did = did;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getMobile() {
		return mobile;
	}

	public void setMobile(int mobile) {
		this.mobile = mobile;
	}

	public String getSpecialization() {
		return specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


	@Override
	public String toString() {
		return "Doctor [did=" + did + ", name=" + name + ", mobile=" + mobile + ", specialization=" + specialization
				+ ", email=" + email + ", password=" + password + ", ]";
	}
	
	

}
